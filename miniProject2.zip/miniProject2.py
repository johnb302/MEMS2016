import numpy as np
from scipy.integrate import odeint, quad
from scipy.optimize import fsolve
import matplotlib.pyplot as plt
from params import params

def g1(phi0,x,p):
    U = x[0]
    V = 0
    G = x[1]
    H = x[2]
    X = x[3]
    Y = x[4]

    ep = p.ep
    gamma = p.gamma
    u0 = p.u0

    # eq 34
    v1mu1 = (V - U) + (G - X)*np.cos(phi0) + (H - Y)*np.sin(phi0)
    # eq 28
    cond = (ep*v1mu1 >= u0 - 1)

    return np.where(cond,gamma*v1mu1*(2*(1-u0)+ep*v1mu1),-1*np.ones(np.size(phi0))*gamma/ep*(1-u0)**2)

def g1Cos(phi0,x,p):
    return g1(phi0,x,p)*np.cos(phi0)

def g1Sin(phi0,x,p):
    return g1(phi0,x,p)*np.sin(phi0)

def hbsystem_case1(x,p):
    # solve this if v1-u1 is not sufficiently large
    mu = p.mu
    a1 = p.a1
    a2 = p.a2
    ep = p.ep
    gamma = p.gamma
    a0 = p.a0cur
    u0 = p.u0

    # corresponding U, V, G, H, X, Y
    U = x[0]
    V = 0
    G = x[1]
    H = x[2]
    X = x[3]
    Y = x[4]

    f1 = -a2*U + 1/2/np.pi*quad(lambda phi0: g1(phi0,x,p),0,2*np.pi)[0]
    f2 = H - Y + a1*G
    f3 = -mu*H + (mu + 1)*Y + a2*X - 1/np.pi*quad(lambda phi0: g1Cos(phi0,x,p),0,2*np.pi)[0]
    f4 = -G + X + a1*H + a0
    f5 = mu*G - (mu + 1)*X + a2*Y - 1/np.pi*quad(lambda phi0: g1Sin(phi0,x,p),0,2*np.pi)[0]
    return [f1, f2, f3, f4, f5]

def odefun(A0, t, p):
    p.setA0cur(A0)

    # solve harmonic balance
    nsolve_ics = [100, 100, 100, 100, 100]
    x = fsolve(hbsystem_case1,nsolve_ics,args=(p,))

    H = x[2]
    return -0.5*(p.lmbda*A0 - H)

if __name__ == '__main__':
    # dimensional parameters
    Cm = 2.201e-15
    Cs = 1.62e-11
    Cg = 2.32e-11
    Lm = 4.496e-2
    Rm = 5.62e1
    Rs = 7.444e3
    Rg = 5.168e4
    Vth = -0.95
    beta = 0.12
    B = 0.8

    # computation of nondimensional parameters
    mu = Cg/Cs
    a1 = np.sqrt(Lm*Cm)/Cg/Rg
    a2 = np.sqrt(Lm*Cm)/Cs/Rs
    ep = np.sqrt(Cm/Cg)
    lmbda = Rm*Cg/np.sqrt(Lm*Cm)
    gamma = beta*np.abs(Vth)*np.sqrt(Lm*Cm)/Cs

    # compute u0 steady state value
    u0 = (1 + a2/2/gamma) - np.sqrt((1 + a2/2/gamma)**2 - 1)
    v0 = 0

    P = params(mu,a1,a2,ep,lmbda,gamma,v0,u0,0,0)
    A0 = P.a0ic

    t = np.linspace(0,200,200)
    results = odeint(odefun, A0, t, args=(P,))

    plt.plot(results[:,0],results[:,1],"b")
    plt.xlabel("Time")
    plt.ylabel("A0")
    plt.show()
    